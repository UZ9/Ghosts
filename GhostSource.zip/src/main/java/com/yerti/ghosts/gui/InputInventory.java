package com.yerti.ghosts.gui;

import org.bukkit.inventory.InventoryHolder;

public interface InputInventory extends InventoryHolder {

}
