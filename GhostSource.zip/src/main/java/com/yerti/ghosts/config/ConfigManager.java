package com.yerti.ghosts.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.Plugin;

import java.io.File;
import java.util.logging.Logger;

public class ConfigManager {

    Plugin plugin;

    public ConfigManager(Plugin plugin) {
        this.plugin = plugin;
    }

    public void initConfig() {
        if (!configExists()) {
            FileConfiguration configuration = plugin.getConfig();
            configuration.options().copyDefaults(true);
            plugin.saveDefaultConfig();
            //plugin.saveResource("config.yml", false);
        }
    }

    private boolean configExists() {
        try {
            File file = new File("plugins/ghosts/config.yml");
            return file.exists();
        } catch (Exception e) {

        }

        return true;
    }

}
